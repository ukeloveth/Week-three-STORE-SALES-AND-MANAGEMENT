package enums;

public enum Role {
    MANAGER,
    CASHIER
}
