package services;

import models.Staff;

public interface StaffServices{
    void work(Staff staff);
}
