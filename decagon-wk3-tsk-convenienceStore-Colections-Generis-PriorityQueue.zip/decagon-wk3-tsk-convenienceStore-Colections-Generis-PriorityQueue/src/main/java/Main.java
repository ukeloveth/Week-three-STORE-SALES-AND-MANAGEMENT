import enums.Gender;
import enums.Role;
import models.Staff;
import models.Store;
import servicesImpl.CashierServicesImpl;

import java.io.IOException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        Store store = new Store();
        Staff staff1  = new Staff(1,"johnny", Gender.MALE,"JOHNNY@live","DEC-JAV-1", Role.CASHIER,"BSC");
        CashierServicesImpl cashierServices = new CashierServicesImpl();
        cashierServices.fetchProductFromStore(staff1,store,"productData.xlsx");
        System.out.println(Arrays.toString(store.getProductList()));
    }
}
